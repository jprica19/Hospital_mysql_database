package edu.uwp.cs.csci380.project.PB.simpleaccess_V2;

import com.jcraft.jsch.JSchException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * The main method will use the coding in the Connection and Configuration classes
 * </p>
 * @throws JSchException
 * @throws SQLException
 */
public class AppMain {
    public static void main(String[] args) throws JSchException, SQLException{

        /**
         * Object of configuration class that accepts the file with information as a parameter
         */
        Configuration configuration = new Configuration("app.properties");

        /**
         * Object of connection class with the configuration as the parameter
         */
        Connection connection = new Connection(configuration);

        /**
         * Establish ssh connection
         */
        connection.sshConnect();

        System.out.println("Establishing SSH tunnel...");
        System.out.println("localhost:4321 -> localhost:3306");
        System.out.println("done.");

        /**
         * Establish database connection
         */
        String sshUsername = "prica";
        String sshPassword = "aR = 5guIh";
        String remoteHost = "basil.cs.uwp.edu";
        connection.dbConnect(connection.username(), connection.password());

        System.out.println("Establishing database connection via tunnel...");
        System.out.println("Enter your database username: " + connection.username());
        System.out.println("Enter your database password " + connection.password());

        System.out.println("Connection URL: " + connection.makeURLstring());
        System.out.println("done.");

        connection.sshConnect();

        connection.dbConnect(configuration.getProperty("db.username"),
                configuration.getProperty("db.password"));

        // Sending query
        connection.dbRunQuery("SELECT * FROM Instrument");

        System.out.println("Running an easy database query...");
        System.out.println("{");

        ResultSet resultSet = connection.dbRunQuery("SELECT * FROM Instrument");

        // Close database connection
        connection.dbClose();
    }
}
