package edu.uwp.cs.csci380.project.PB.simpleaccess_V2;

import java.io.IOException;
import java.util.Properties;
import java.io.FileReader;

/**
 * This class reads from the file that has been created to provide the data.
 * Each time used, the file app.properties can be edited rather than being hardcoded
 */
public class Configuration {
    // Object of property class
    private Properties properties;


    /**
     * The application reads the file and sets configuration parameters accordingly.
     * </p>
     * This is where the configuration file is read into a Properties object.
     * @param configFile is the file to be analyzed
     *                   (app.properties file)
     */

    public Configuration(String configFile){

        properties = new Properties();
        try{
            //FileReader will read from app.properties file
            FileReader file = new FileReader(configFile);
            properties.load(file);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * This method will retrieve the name of the Property from the file
     * </p>
     * @param nameProp is the property we get from app.properties
     * </p>
     * @return the property
     */

    public String getProperty(String nameProp){
        return properties.getProperty(nameProp);
    }

    /**
     * This method has the key that points to the property on the file and the value of the property
     * </p>
     * @param keyProp is the property we get from app.properties
     * </p>
     * @param valueProp is the property we get from app.properties
     */

    public void setProperty(String keyProp, String valueProp){
        properties.setProperty(keyProp, valueProp);
    }
}
