package edu.uwp.cs.csci380.project.PB.simpleaccess_V2;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Connection {
    // private final java.sql.Connection dbConnection;

    private Configuration configure;
    private java.sql.Connection dbConnection;

    /**
     *  Constructor that takes a Configuration object
     */
    public Connection (Configuration configure){ this.configure = configure;}

    /**
     * Set up the SSH tunnel and port forwarding
     */

    public void sshConnect(){
        // Implement SSH tunnel setup using configuration properties
        String sshHost = configure.getProperty("ssh.host");
        int port = Integer.parseInt(configure.getProperty("ssh.port"));
        String username = configure.getProperty("ssh.username");
        String password = configure.getProperty("ssh.password");

        // Implement SSH Tunnel logic structure

        System.out.println("Establishing SSH tunnel...");
        System.out.println("localhost:" + configure.getProperty("local.database.port") +
                " -> localhost:3306");
        System.out.println("done.");
    }

    /**
     * Connect to the database using a username and password
     */

    public void dbConnect(String username, String password){
        String dbURL = makeURLstring();
        String dbDriver = makeDriverString();
        java.sql.Connection dbConnection = this.dbConnection;
        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                Class.forName(dbDriver);
                dbConnection = DriverManager.getConnection(dbURL, username, password);
                System.out.println("Establishing database connection via tunnel...");
                System.out.println("Connection URL: " + dbURL);
                System.out.println("done.");
            }
        } catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * Run a database query using the provided query string
     */
    public ResultSet dbRunQuery(String queryString){
        try{
            if(dbConnection != null){
                java.sql.Statement stmt = dbConnection.createStatement();
                return stmt.executeQuery(queryString);
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Close the database connection
     */

    public void dbClose(){
        try{
            if(dbConnection != null && !dbConnection.isClosed()){
                dbConnection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * Private method to construct the database URL based on configuration properties
     */

    String makeURLstring(){
        String dbType = configure.getProperty("db.database");
        String dbHost = configure.getProperty("remote.database.host");
        int port = Integer.parseInt(configure.getProperty("remote.database.port"));
        String dbName = configure.getProperty("db.name");
        return "jdbc:" + dbType + "://" + dbHost + ":" + port + "/" +dbName + "?characterEncoding=utf8";
    }

    /**
     * Private method to construct the database driver
     */
    String makeDriverString(){
        return configure.getProperty("db.driver");
    }

    public String username(){
        String usernameDb = configure.getProperty("db.username");

        return usernameDb;
    }

    public String password(){
        String passDb = configure.getProperty("db.password");
        return passDb;
    }
}
